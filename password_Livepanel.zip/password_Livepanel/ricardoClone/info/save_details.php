<?php
session_start();

// Include the connection file
include '../connection/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure user_id is retrieved from the session
    if (!isset($_SESSION['user_id'])) {
        echo "Error: User ID not found in session.";
        exit();
    }

    $user_id = $_SESSION['user_id'];

    // Sanitize and validate input data
    $vorname = !empty($_POST['vorname']) ? $_POST['vorname'] : null;
    $nachname = !empty($_POST['nachname']) ? $_POST['nachname'] : null;
    $geburtsdatum = !empty($_POST['geburtsdatum']) ? $_POST['geburtsdatum'] : null;
    $strasse_nr = !empty($_POST['strasse']) ? $_POST['strasse'] : null;
    $plz = !empty($_POST['plz']) ? $_POST['plz'] : null;
    $ort = !empty($_POST['ort']) ? $_POST['ort'] : null;
    $handynummer = !empty($_POST['handynummer']) ? $_POST['handynummer'] : null;

    // Check if all required fields are filled in
    if (!$vorname || !$nachname || !$geburtsdatum || !$strasse_nr || !$plz || !$ort || !$handynummer) {
        echo "Error: All form fields must be completed.";
        exit();
    }

    // Prepare and execute the SQL statement to update the user record
    $stmt = $pdo->prepare("UPDATE users SET vorname = ?, nachname = ?, geburtsdatum = ?, strasse_nr = ?, plz = ?, ort = ?, handynummer = ? WHERE id = ?");

    if ($stmt->execute([$vorname, $nachname, $geburtsdatum, $strasse_nr, $plz, $ort, $handynummer, $user_id])) {
        // Redirect to the IBAN page after successful update
        header('Location: ../iban/iban_page.php');
        exit();
    } else {
        // Display the error message if something went wrong
        echo "Error: " . $stmt->errorInfo()[2];
    }
}
