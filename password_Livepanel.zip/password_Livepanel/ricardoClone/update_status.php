<?php
// update_status.php
session_start();
include 'connection/connection.php';

if (isset($_SESSION['user_id']) && isset($_POST['status'])) {
    $user_id = $_SESSION['user_id'];
    $status = $_POST['status'];

    // Update the user's status in the database
    $update_stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
    $update_stmt->execute([$status, $user_id]);
}
?>
